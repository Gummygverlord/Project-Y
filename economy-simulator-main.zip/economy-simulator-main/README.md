# economy-simulator
Source code for the ROBLOX Revival economy-simulator.com fucking insecure asl please for the love of god do not hostthis

# No this is not the .org version
There is a prewritten guide by floatzel named README.txt
