const NotAvailable = props => {
  return <div className='row'>
    <div className='col-12'>
      <p className='mt-2'>This feature is not available right now.</p>
    </div>
  </div>
}

export default NotAvailable;