namespace Roblox.Dto.Users;

public class Alert
{
    public string message { get; set; }
    public string? url { get; set; }
}