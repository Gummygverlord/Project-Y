namespace Roblox.Exceptions.Services.Users;

public class NotEnoughRobuxForPurchaseException : Exception { }